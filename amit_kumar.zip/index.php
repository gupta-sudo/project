<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>RazorPay Payment Integration Demo</title>
        <link rel="stylesheet" href="./css/style.css" media="screen" title="no title" charset="utf-8">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <meta name="robots" content="noindex,follow" />
    </head>

<body>
    <div class="shopping-cart">
      <!-- Title -->
      <div class="title">
        RazorPay Payment Integration Demo
      </div>
	<form method="POST">
		<input type="hidden" name="productId" id="productId" value="PRO121">
      <!-- Product #1 -->
      <div class="item">
        
        <div class="image">
          <img src="dummy.jpg" alt="" />
        </div>

        <div class="description">
          <span>Common Projects</span>
          <span>This is dummy product</span>
        </div>


        <div class="total-price">
        <input style="border: none;font-size: 20px;" type="text" name="price" id="price" value="100" class="rupee" readonly>
        </div>
        <button id="payButton" class="btnAction">Buy Now</button>
      </div>
	</form>		  	
    </div>


    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script>

        $(document).ready(function() {
        
        $("#payButton").click(function(e) {
            
            var getAmount = $("#price").val();
            var product_id =  $("#productId").val();
            var useremail =  'dummyuseremail@gamil.com';
            
            var totalAmount = getAmount * 100;
            
            var options = {
                        "key": "rzp_test_pn5HAQj3W3N9vX", // your Razorpay Key Id
                        "amount": totalAmount,
                        "name": "Product Name",
                        "description": "Dummy Product",
                        "image": "https://www.codefixup.com/wp-content/uploads/2016/03/logo.png",
                        "handler": function (response){
                        $.ajax({
                                url: 'ajax-payment.php',
                                type: 'post',
                                dataType: 'json',
                                data: {
                                        razorpay_payment_id: response.razorpay_payment_id , totalAmount : totalAmount ,product_id : product_id ,useremail : useremail,
                                    }, 
                                success: function (data) 
                                {
                                    //alert(data.msg);
                                    
                                    window.location.href = 'success.php/?productCode='+ data.productCode +'&payId='+ data.paymentID +'&userEmail='+ data.userEmail +'';
                                    
                                }
                            });
                        },
                        "theme": {
                        "color": "#528FF0"
                                }
                        };

            var rzp1 = new Razorpay(options);
            rzp1.open();
            e.preventDefault();
    });

    });
    </script>

  </body>
</html>
