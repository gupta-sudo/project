<!DOCTYPE html>
 <html>
 <head>
 <title>Thank You</title>

 </head>
 <body>

 <div align="center">
 <h4>Thank you for payment<br></h4>
 <br>
 <p><a target="_blank" href="/"> Back to Home</a></p>
 </div>

</body>
</html>